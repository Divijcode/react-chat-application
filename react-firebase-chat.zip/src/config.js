import * as firebase from 'firebase/app'

const firebaseConfig = {
    apiKey: "AIzaSyB938m0swwtucw1ezwgvRV_VII8bWk_y48",
  authDomain: "chatapplication-f448b.firebaseapp.com",
  projectId: "chatapplication-f448b",
  databaseURL: "https://chatapplication-f448b-default-rtdb.firebaseio.com",
  storageBucket: "chatapplication-f448b.appspot.com",
  messagingSenderId: "175280070371",
  appId: "1:175280070371:web:58fad9ffeefd2b20092fd6",
  measurementId: "G-V6JDQDJMNX"
  
}
// firebase.initializeApp(config);

export {firebaseConfig};