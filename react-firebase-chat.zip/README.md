Chat Application using React.JS + Firebase real-time Database + Firebase Gmail Authentication
=====================================

I build this app for learning purpose. you can check the live 💁‍♂️ [demo](https://chatroom-67e21.web.app/) 

![](https://firebasestorage.googleapis.com/v0/b/chatroom-67e21.appspot.com/o/chat-chat.png?alt=media&token=3ad066ef-e277-4113-a496-e8fa6c110832)

Quick Start:
------------

- ``` git clone ```
- ``` cd react-firebase-chat ```
- create a firebase config file on /src
- ``` npm install ```
- ``` npm start ```
